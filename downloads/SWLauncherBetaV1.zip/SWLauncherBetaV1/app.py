import sys
import os
import shutil
import tempfile
from pathlib import Path

from PIL import Image

from PySide6.QtCore import Qt, QPointF, QSize
from PySide6.QtGui import (
    QImage, QPixmap, QColor, QPainter, QPen,
    QBrush, QAction
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QListWidget,
    QListWidgetItem, QFileDialog, QMessageBox,
    QLineEdit, QStackedWidget, QFrame, QSplitter,
    QTreeWidget, QTreeWidgetItem, QColorDialog,
    QSlider, QSpinBox, QScrollArea, QInputDialog,
    QCheckBox, QToolButton
)


APP_NAME = "SWLAUNCHER"
VERSION = "1.1"

GD_DEFAULT = Path(
    r"C:\Program Files (x86)\Steam\steamapps\common"
    r"\Geometry Dash\Resources\icons"
)

ROBLOX_VERSIONS = (
    Path(os.environ.get("LOCALAPPDATA", ""))
    / "Roblox" / "Versions"
)

IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".bmp",
    ".tga", ".dds", ".webp"
}

BACKUP_FOLDER = Path.home() / "SWLAUNCHER_Backups"


# --------------------------------------------------
# STYLE
# --------------------------------------------------

BLUE_STYLE = """
QMainWindow, QWidget {
    background-color: #101b35;
    color: #eaf3ff;
    font-family: Arial;
    font-size: 13px;
}

#Sidebar {
    background-color: #142443;
    border: 1px solid #263d65;
    border-radius: 15px;
}

#Logo {
    color: #72bdff;
    font-size: 25px;
    font-weight: bold;
}

#Version, #Muted {
    color: #8da8cf;
}

#PageTitle {
    color: #8bcaff;
    font-size: 27px;
    font-weight: bold;
}

#Preview {
    background-color: #172746;
    border: 1px solid #345780;
    border-radius: 12px;
}

QPushButton, QToolButton {
    background-color: #234a7c;
    color: white;
    border: 1px solid #386da8;
    border-radius: 9px;
    padding: 9px;
    font-weight: bold;
}

QPushButton:hover, QToolButton:hover {
    background-color: #326bb0;
    border: 1px solid #75baff;
}

QPushButton:checked, QToolButton:checked {
    background-color: #397ec8;
    border: 1px solid #9bcfff;
}

QLineEdit, QSpinBox {
    background-color: #192d50;
    color: white;
    border: 1px solid #345780;
    border-radius: 9px;
    padding: 9px;
}

QListWidget, QTreeWidget {
    background-color: #172746;
    border: 1px solid #29466e;
    border-radius: 10px;
    outline: none;
}

QListWidget::item, QTreeWidget::item {
    padding: 7px;
}

QListWidget::item:selected,
QTreeWidget::item:selected {
    background-color: #326bb0;
    color: white;
}

QSlider::groove:horizontal {
    height: 6px;
    background: #29466e;
    border-radius: 3px;
}

QSlider::handle:horizontal {
    background: #72bdff;
    width: 15px;
    margin: -5px 0;
    border-radius: 7px;
}

QSplitter::handle {
    background-color: #29466e;
}

QScrollArea {
    border: 1px solid #345780;
    border-radius: 10px;
    background: #172746;
}
"""


# --------------------------------------------------
# IMAGE UTILITIES
# --------------------------------------------------

def load_image_pixmap(path, width, height):
    try:
        with Image.open(path) as image:
            image.load()
            image = image.convert("RGBA")
            image.thumbnail(
                (width, height),
                Image.Resampling.LANCZOS
            )

            data = image.tobytes("raw", "RGBA")

            qimage = QImage(
                data,
                image.width,
                image.height,
                image.width * 4,
                QImage.Format.Format_RGBA8888
            ).copy()

            return QPixmap.fromImage(qimage)

    except Exception:
        return QPixmap()


def is_image(path):
    try:
        if path.suffix.lower() not in IMAGE_EXTENSIONS:
            return False

        with Image.open(path) as image:
            image.verify()

        return True

    except Exception:
        return False


def pil_to_qimage(image):
    image = image.convert("RGBA")

    data = image.tobytes("raw", "RGBA")

    return QImage(
        data,
        image.width,
        image.height,
        image.width * 4,
        QImage.Format.Format_RGBA8888
    ).copy()


def qimage_to_pil(image):
    image = image.convertToFormat(
        QImage.Format.Format_RGBA8888
    )

    width = image.width()
    height = image.height()

    data = image.bits().tobytes()

    return Image.frombytes(
        "RGBA",
        (width, height),
        data
    )


def save_image_to_texture(source_image, destination):
    """
    Remplace une texture en conservant ses dimensions
    et son format lorsque Pillow sait l'écrire.
    """

    destination = Path(destination)

    with Image.open(destination) as original:
        original.load()

        original_size = original.size
        original_format = original.format

    replacement = source_image.convert("RGBA")

    if replacement.size != original_size:
        replacement = replacement.resize(
            original_size,
            Image.Resampling.LANCZOS
        )

    extension = destination.suffix.lower()

    formats = {
        ".png": "PNG",
        ".jpg": "JPEG",
        ".jpeg": "JPEG",
        ".bmp": "BMP",
        ".tga": "TGA",
        ".dds": "DDS",
        ".webp": "WEBP"
    }

    output_format = formats.get(
        extension,
        original_format or "PNG"
    )

    if output_format == "JPEG":
        replacement = replacement.convert("RGB")

    temporary = destination.with_name(
        destination.stem + "_swlauncher_temp" + destination.suffix
    )

    try:
        replacement.save(
            temporary,
            format=output_format
        )

        os.replace(temporary, destination)

    finally:
        if temporary.exists():
            temporary.unlink()

    return original_size


# --------------------------------------------------
# BACKUPS
# --------------------------------------------------

def backup_texture(texture_path, root_path, game_name):
    texture_path = Path(texture_path)
    root_path = Path(root_path)

    relative = texture_path.relative_to(root_path)

    backup = (
        BACKUP_FOLDER
        / game_name
        / relative
    )

    backup.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    if not backup.exists():
        shutil.copy2(texture_path, backup)

    return backup


def restore_texture(texture_path, root_path, game_name):
    texture_path = Path(texture_path)
    root_path = Path(root_path)

    relative = texture_path.relative_to(root_path)

    backup = (
        BACKUP_FOLDER
        / game_name
        / relative
    )

    if not backup.exists():
        raise FileNotFoundError(
            "Aucune sauvegarde originale trouvée."
        )

    shutil.copy2(backup, texture_path)


# --------------------------------------------------
# ROBLOX DETECTION
# --------------------------------------------------

def find_roblox_textures():

    if not ROBLOX_VERSIONS.exists():
        return None

    candidates = []

    try:
        for version_folder in ROBLOX_VERSIONS.iterdir():

            if not version_folder.is_dir():
                continue

            textures = (
                version_folder
                / "content"
                / "textures"
            )

            if textures.is_dir():
                try:
                    modified = version_folder.stat().st_mtime
                except OSError:
                    modified = 0

                candidates.append(
                    (modified, textures)
                )

    except OSError:
        return None

    if not candidates:
        return None

    candidates.sort(
        key=lambda item: item[0],
        reverse=True
    )

    return candidates[0][1]


# --------------------------------------------------
# TEXTURE BROWSER
# --------------------------------------------------

class TextureBrowser(QWidget):

    def __init__(
        self,
        title_text,
        description_text,
        default_folder=None,
        backup_name="",
        on_edit=None
    ):
        super().__init__()

        self.default_folder = default_folder
        self.root_path = None
        self.current_folder = None

        self.backup_name = backup_name
        self.on_edit = on_edit

        self.selected_image = None
        self.image_paths = []

        self.setup_ui(
            title_text,
            description_text
        )

    def setup_ui(self, title_text, description_text):

        layout = QVBoxLayout(self)

        title = QLabel(title_text)
        title.setObjectName("PageTitle")

        description = QLabel(description_text)

        self.folder_label = QLabel(
            "Aucun dossier sélectionné."
        )
        self.folder_label.setObjectName("Muted")
        self.folder_label.setWordWrap(True)

        toolbar = QHBoxLayout()

        self.search = QLineEdit()
        self.search.setPlaceholderText(
            "Rechercher une image..."
        )

        self.search.textChanged.connect(
            self.refresh_file_list
        )

        choose_button = QPushButton(
            "Choisir un dossier"
        )
        choose_button.clicked.connect(
            self.choose_folder
        )

        refresh_button = QPushButton(
            "Actualiser"
        )
        refresh_button.clicked.connect(
            self.refresh_browser
        )

        toolbar.addWidget(self.search, 1)
        toolbar.addWidget(choose_button)
        toolbar.addWidget(refresh_button)

        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMinimumWidth(190)

        self.tree.itemClicked.connect(
            self.on_folder_selected
        )

        self.file_list = QListWidget()

        self.file_list.itemClicked.connect(
            self.preview_selected
        )

        self.file_list.itemDoubleClicked.connect(
            self.edit_selected
        )

        self.preview = QLabel(
            "Sélectionne une image."
        )
        self.preview.setObjectName("Preview")
        self.preview.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )
        self.preview.setMinimumWidth(260)
        self.preview.setWordWrap(True)

        self.info_label = QLabel("")
        self.info_label.setObjectName("Muted")
        self.info_label.setWordWrap(True)

        self.count_label = QLabel("0 image")
        self.count_label.setObjectName("Muted")

        splitter = QSplitter(
            Qt.Orientation.Horizontal
        )

        splitter.addWidget(self.tree)
        splitter.addWidget(self.file_list)
        splitter.addWidget(self.preview)

        splitter.setSizes([220, 300, 400])

        layout.addWidget(title)
        layout.addWidget(description)
        layout.addWidget(self.folder_label)
        layout.addLayout(toolbar)
        layout.addWidget(self.count_label)
        layout.addWidget(splitter, 1)
        layout.addWidget(self.info_label)

        actions = QHBoxLayout()

        edit_button = QPushButton(
            "Modifier avec SWPaint"
        )
        edit_button.clicked.connect(
            self.edit_selected
        )

        replace_button = QPushButton(
            "Remplacer depuis le PC"
        )
        replace_button.clicked.connect(
            self.replace_image
        )

        restore_button = QPushButton(
            "Restaurer l'original"
        )
        restore_button.clicked.connect(
            self.restore_image
        )

        actions.addWidget(edit_button)
        actions.addWidget(replace_button)
        actions.addWidget(restore_button)

        layout.addLayout(actions)

    # --------------------------------------------------
    # FOLDERS
    # --------------------------------------------------

    def choose_folder(self):

        folder = QFileDialog.getExistingDirectory(
            self,
            "Choisir un dossier",
            str(self.root_path or Path.home())
        )

        if folder:
            self.load_root(Path(folder))

    def load_root(self, folder):

        folder = Path(folder)

        if not folder.is_dir():
            return

        self.root_path = folder
        self.current_folder = folder

        self.folder_label.setText(
            f"Dossier : {folder}"
        )

        self.build_folder_tree()
        self.refresh_file_list()

    def build_folder_tree(self):

        self.tree.clear()

        if not self.root_path:
            return

        root_item = QTreeWidgetItem([
            self.root_path.name or str(self.root_path)
        ])

        root_item.setData(
            0,
            Qt.ItemDataRole.UserRole,
            str(self.root_path)
        )

        self.tree.addTopLevelItem(root_item)

        self.add_subfolders(
            root_item,
            self.root_path,
            0
        )

        root_item.setExpanded(True)
        self.tree.setCurrentItem(root_item)

    def add_subfolders(self, parent_item, folder, depth):

        if depth >= 5:
            return

        try:
            folders = sorted(
                [
                    path for path in folder.iterdir()
                    if path.is_dir()
                ],
                key=lambda path: path.name.lower()
            )

        except OSError:
            return

        for folder_path in folders:

            item = QTreeWidgetItem([
                folder_path.name
            ])

            item.setData(
                0,
                Qt.ItemDataRole.UserRole,
                str(folder_path)
            )

            parent_item.addChild(item)

            self.add_subfolders(
                item,
                folder_path,
                depth + 1
            )

    def on_folder_selected(self, item, column):

        folder = item.data(
            0,
            Qt.ItemDataRole.UserRole
        )

        if folder:
            self.current_folder = Path(folder)
            self.refresh_file_list()

    # --------------------------------------------------
    # FILES
    # --------------------------------------------------

    def refresh_file_list(self):

        previous = self.selected_image

        self.file_list.clear()
        self.image_paths.clear()

        self.selected_image = None

        self.preview.clear()
        self.preview.setText(
            "Sélectionne une image."
        )

        self.info_label.clear()

        if not self.current_folder:
            return

        search_text = self.search.text().lower()

        try:
            files = sorted(
                self.current_folder.iterdir(),
                key=lambda path: path.name.lower()
            )

        except OSError:
            return

        selected_item = None

        for path in files:

            if not path.is_file():
                continue

            if path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue

            if search_text not in path.name.lower():
                continue

            self.image_paths.append(path)

            item = QListWidgetItem(
                f"🖼  {path.name}"
            )

            item.setData(
                Qt.ItemDataRole.UserRole,
                str(path)
            )

            self.file_list.addItem(item)

            if previous and path == previous:
                selected_item = item

        self.count_label.setText(
            f"{len(self.image_paths)} image(s) "
            f"dans {self.current_folder.name}"
        )

        if selected_item:
            self.file_list.setCurrentItem(selected_item)
            self.preview_selected(selected_item)

    def preview_selected(self, item):

        path = Path(
            item.data(Qt.ItemDataRole.UserRole)
        )

        self.selected_image = path

        pixmap = load_image_pixmap(
            path,
            550,
            450
        )

        self.preview.clear()

        if pixmap.isNull():
            self.preview.setText(
                "Aperçu indisponible."
            )
        else:
            self.preview.setPixmap(pixmap)

        try:
            size = path.stat().st_size / 1024

            with Image.open(path) as image:
                dimensions = (
                    f"{image.width} × {image.height}"
                )

        except Exception:
            size = 0
            dimensions = "Inconnues"

        self.info_label.setText(
            f"Nom : {path.name}\n"
            f"Format : {path.suffix.upper()}\n"
            f"Dimensions : {dimensions}\n"
            f"Taille : {size:.1f} Ko\n"
            f"Chemin : {path}"
        )

    def refresh_browser(self):

        if self.root_path:
            self.build_folder_tree()
            self.refresh_file_list()

    # --------------------------------------------------
    # SWPAINT
    # --------------------------------------------------

    def edit_selected(self, item=None):

        if not self.selected_image:
            QMessageBox.warning(
                self,
                "SWLAUNCHER",
                "Sélectionne d'abord une texture."
            )
            return

        if self.on_edit:
            self.on_edit(
                self.selected_image,
                self.root_path,
                self.backup_name
            )

    # --------------------------------------------------
    # REPLACEMENT
    # --------------------------------------------------

    def replace_image(self):

        if not self.selected_image:
            QMessageBox.warning(
                self,
                "SWLAUNCHER",
                "Sélectionne d'abord une image."
            )
            return

        source, _ = QFileDialog.getOpenFileName(
            self,
            "Choisir une image",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp *.webp *.tga)"
        )

        if not source:
            return

        try:
            backup_texture(
                self.selected_image,
                self.root_path,
                self.backup_name
            )

            with Image.open(source) as image:
                image.load()
                replacement = image.convert("RGBA")

            original_size = save_image_to_texture(
                replacement,
                self.selected_image
            )

            QMessageBox.information(
                self,
                "SWLAUNCHER",
                "Texture remplacée !\n\n"
                f"Dimensions conservées : "
                f"{original_size[0]} × {original_size[1]}"
            )

            self.refresh_file_list()

        except Exception as error:

            QMessageBox.critical(
                self,
                "Erreur",
                f"Impossible de remplacer la texture :\n{error}"
            )

    # --------------------------------------------------
    # RESTORE
    # --------------------------------------------------

    def restore_image(self):

        if not self.selected_image:
            QMessageBox.warning(
                self,
                "SWLAUNCHER",
                "Sélectionne d'abord une image."
            )
            return

        try:
            restore_texture(
                self.selected_image,
                self.root_path,
                self.backup_name
            )

            QMessageBox.information(
                self,
                "SWLAUNCHER",
                "Texture originale restaurée !"
            )

            self.refresh_file_list()

        except Exception as error:

            QMessageBox.warning(
                self,
                "Restauration impossible",
                str(error)
            )


# --------------------------------------------------
# SWPAINT CANVAS
# --------------------------------------------------

class PaintCanvas(QWidget):

    def __init__(self):
        super().__init__()

        self.image = QImage(
            800,
            600,
            QImage.Format.Format_RGBA8888
        )

        self.image.fill(Qt.GlobalColor.transparent)

        self.brush_color = QColor("#ffffff")
        self.brush_size = 8

        self.eraser = False
        self.eyedropper = False

        self.zoom = 1.0

        self.drawing = False
        self.last_point = QPointF()

        self.undo_stack = []
        self.redo_stack = []

        self.setMouseTracking(True)
        self.update_size()

    def update_size(self):

        self.setFixedSize(
            max(1, int(self.image.width() * self.zoom)),
            max(1, int(self.image.height() * self.zoom))
        )

        self.update()

    def set_image(self, image):

        self.image = image.convertToFormat(
            QImage.Format.Format_RGBA8888
        )

        self.undo_stack.clear()
        self.redo_stack.clear()

        self.update_size()

    def snapshot(self):

        self.undo_stack.append(self.image.copy())

        if len(self.undo_stack) > 30:
            self.undo_stack.pop(0)

        self.redo_stack.clear()

    def undo(self):

        if not self.undo_stack:
            return

        self.redo_stack.append(self.image.copy())
        self.image = self.undo_stack.pop()

        self.update()

    def redo(self):

        if not self.redo_stack:
            return

        self.undo_stack.append(self.image.copy())
        self.image = self.redo_stack.pop()

        self.update()

    def paintEvent(self, event):

        painter = QPainter(self)

        painter.fillRect(
            self.rect(),
            QColor("#243858")
        )

        painter.save()

        painter.scale(self.zoom, self.zoom)

        tile_size = 16

        for y in range(0, self.image.height(), tile_size):
            for x in range(0, self.image.width(), tile_size):

                color = (
                    QColor("#d8e1ec")
                    if ((x // tile_size + y // tile_size) % 2 == 0)
                    else QColor("#ffffff")
                )

                painter.fillRect(
                    x,
                    y,
                    tile_size,
                    tile_size,
                    color
                )

        painter.drawImage(
            0,
            0,
            self.image
        )

        painter.restore()

    def image_point(self, position):

        return QPointF(
            position.x() / self.zoom,
            position.y() / self.zoom
        )

    def mousePressEvent(self, event):

        if event.button() != Qt.MouseButton.LeftButton:
            return

        point = self.image_point(event.position())

        if self.eyedropper:

            x = int(point.x())
            y = int(point.y())

            if (
                0 <= x < self.image.width()
                and 0 <= y < self.image.height()
            ):
                color = self.image.pixelColor(x, y)

                if color.alpha() > 0:
                    self.brush_color = color

            self.eyedropper = False
            return

        self.snapshot()

        self.drawing = True
        self.last_point = point

        self.draw_line(point, point)

    def mouseMoveEvent(self, event):

        if not self.drawing:
            return

        point = self.image_point(event.position())

        self.draw_line(
            self.last_point,
            point
        )

        self.last_point = point

    def mouseReleaseEvent(self, event):

        if event.button() == Qt.MouseButton.LeftButton:
            self.drawing = False

    def draw_line(self, start, end):

        painter = QPainter(self.image)

        painter.setRenderHint(
            QPainter.RenderHint.Antialiasing
        )

        if self.eraser:
            painter.setCompositionMode(
                QPainter.CompositionMode.CompositionMode_Clear
            )
        else:
            painter.setCompositionMode(
                QPainter.CompositionMode.CompositionMode_SourceOver
            )

        pen = QPen(
            self.brush_color,
            self.brush_size,
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin
        )

        painter.setPen(pen)
        painter.drawLine(start, end)
        painter.end()

        self.update()


# --------------------------------------------------
# SWPAINT PAGE
# --------------------------------------------------

class SWPaint(QWidget):

    def __init__(self, apply_callback):
        super().__init__()

        self.apply_callback = apply_callback

        self.target_path = None
        self.target_root = None
        self.target_game = None

        self.setup_ui()

    def setup_ui(self):

        layout = QVBoxLayout(self)

        title = QLabel("SWPaint")
        title.setObjectName("PageTitle")

        description = QLabel(
            "Éditeur de textures intégré à SWLAUNCHER."
        )

        toolbar = QHBoxLayout()

        self.new_button = QPushButton("Nouveau")
        self.new_button.clicked.connect(self.new_canvas)

        self.open_button = QPushButton("Ouvrir une image")
        self.open_button.clicked.connect(self.open_image)

        self.save_button = QPushButton("Exporter PNG")
        self.save_button.clicked.connect(self.export_image)

        toolbar.addWidget(self.new_button)
        toolbar.addWidget(self.open_button)
        toolbar.addWidget(self.save_button)

        tools = QHBoxLayout()

        self.brush_button = QPushButton("Pinceau")
        self.brush_button.setCheckable(True)
        self.brush_button.setChecked(True)

        self.eraser_button = QPushButton("Gomme")
        self.eraser_button.setCheckable(True)

        self.eyedropper_button = QPushButton("Pipette")
        self.eyedropper_button.setCheckable(True)

        self.brush_button.clicked.connect(
            self.use_brush
        )

        self.eraser_button.clicked.connect(
            self.use_eraser
        )

        self.eyedropper_button.clicked.connect(
            self.use_eyedropper
        )

        tools.addWidget(self.brush_button)
        tools.addWidget(self.eraser_button)
        tools.addWidget(self.eyedropper_button)

        self.color_button = QPushButton("Couleur")
        self.color_button.clicked.connect(
            self.choose_color
        )

        tools.addWidget(self.color_button)

        tools.addWidget(QLabel("Largeur :"))

        self.size_spin = QSpinBox()
        self.size_spin.setRange(1, 100)
        self.size_spin.setValue(8)
        self.size_spin.valueChanged.connect(
            self.change_size
        )

        tools.addWidget(self.size_spin)

        undo_button = QPushButton("Annuler")
        undo_button.clicked.connect(
            self.canvas_undo
        )

        redo_button = QPushButton("Rétablir")
        redo_button.clicked.connect(
            self.canvas_redo
        )

        tools.addWidget(undo_button)
        tools.addWidget(redo_button)

        zoom_layout = QHBoxLayout()

        zoom_layout.addWidget(QLabel("Zoom"))

        self.zoom_slider = QSlider(
            Qt.Orientation.Horizontal
        )

        self.zoom_slider.setRange(25, 300)
        self.zoom_slider.setValue(100)

        self.zoom_slider.valueChanged.connect(
            self.change_zoom
        )

        self.zoom_label = QLabel("100 %")

        zoom_layout.addWidget(self.zoom_slider, 1)
        zoom_layout.addWidget(self.zoom_label)

        self.canvas = PaintCanvas()

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )
        self.scroll.setWidget(self.canvas)

        self.target_label = QLabel(
            "Aucune texture associée."
        )
        self.target_label.setObjectName("Muted")
        self.target_label.setWordWrap(True)

        self.apply_button = QPushButton(
            "Enregistrer sur la texture sélectionnée"
        )

        self.apply_button.clicked.connect(
            self.apply_to_texture
        )

        layout.addWidget(title)
        layout.addWidget(description)
        layout.addLayout(toolbar)
        layout.addLayout(tools)
        layout.addLayout(zoom_layout)
        layout.addWidget(self.scroll, 1)
        layout.addWidget(self.target_label)
        layout.addWidget(self.apply_button)

    # --------------------------------------------------
    # TOOLS
    # --------------------------------------------------

    def use_brush(self):

        self.canvas.eraser = False
        self.canvas.eyedropper = False

        self.brush_button.setChecked(True)
        self.eraser_button.setChecked(False)
        self.eyedropper_button.setChecked(False)

    def use_eraser(self):

        self.canvas.eraser = True
        self.canvas.eyedropper = False

        self.brush_button.setChecked(False)
        self.eraser_button.setChecked(True)
        self.eyedropper_button.setChecked(False)

    def use_eyedropper(self):

        self.canvas.eraser = False
        self.canvas.eyedropper = True

        self.brush_button.setChecked(False)
        self.eraser_button.setChecked(False)
        self.eyedropper_button.setChecked(True)

    def choose_color(self):

        color = QColorDialog.getColor(
            self.canvas.brush_color,
            self,
            "Choisir une couleur"
        )

        if color.isValid():
            self.canvas.brush_color = color

        self.use_brush()

    def change_size(self, value):
        self.canvas.brush_size = value

    def change_zoom(self, value):

        self.canvas.zoom = value / 100

        self.canvas.update_size()

        self.zoom_label.setText(
            f"{value} %"
        )

    def canvas_undo(self):
        self.canvas.undo()

    def canvas_redo(self):
        self.canvas.redo()

    # --------------------------------------------------
    # CANVAS
    # --------------------------------------------------

    def new_canvas(self):

        width, ok = QInputDialog.getInt(
            self,
            "Nouveau canvas",
            "Largeur :",
            800,
            1,
            4096
        )

        if not ok:
            return

        height, ok = QInputDialog.getInt(
            self,
            "Nouveau canvas",
            "Hauteur :",
            600,
            1,
            4096
        )

        if not ok:
            return

        transparent = QMessageBox.question(
            self,
            "Arrière-plan",
            "Créer un fond transparent ?",
            QMessageBox.StandardButton.Yes
            | QMessageBox.StandardButton.No
        )

        image = QImage(
            width,
            height,
            QImage.Format.Format_RGBA8888
        )

        if transparent == QMessageBox.StandardButton.Yes:
            image.fill(Qt.GlobalColor.transparent)

        else:
            color = QColorDialog.getColor(
                QColor("#ffffff"),
                self,
                "Couleur du fond"
            )

            if not color.isValid():
                color = QColor("#ffffff")

            image.fill(color)

        self.canvas.set_image(image)

        self.target_path = None
        self.target_root = None
        self.target_game = None

        self.target_label.setText(
            "Nouveau canvas — aucune texture associée."
        )

    def open_image(self):

        path, _ = QFileDialog.getOpenFileName(
            self,
            "Ouvrir une image",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp *.webp *.tga)"
        )

        if not path:
            return

        try:
            with Image.open(path) as image:
                image.load()
                qimage = pil_to_qimage(image)

            self.canvas.set_image(qimage)

            self.target_path = None
            self.target_root = None
            self.target_game = None

            self.target_label.setText(
                f"Image importée : {path}"
            )

        except Exception as error:

            QMessageBox.critical(
                self,
                "Erreur",
                f"Impossible d'ouvrir cette image :\n{error}"
            )

    def export_image(self):

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Exporter l'image",
            str(Path.home() / "SWPaint.png"),
            "PNG (*.png)"
        )

        if not path:
            return

        if not path.lower().endswith(".png"):
            path += ".png"

        try:
            image = qimage_to_pil(
                self.canvas.image
            )

            image.save(path, format="PNG")

            QMessageBox.information(
                self,
                "SWPaint",
                "Image exportée avec succès !"
            )

        except Exception as error:

            QMessageBox.critical(
                self,
                "Erreur",
                str(error)
            )

    # --------------------------------------------------
    # OPEN TEXTURE FROM BROWSER
    # --------------------------------------------------

    def load_texture(self, path, root, game_name):

        try:
            with Image.open(path) as image:
                image.load()
                qimage = pil_to_qimage(image)

            self.canvas.set_image(qimage)

            self.target_path = Path(path)
            self.target_root = Path(root)
            self.target_game = game_name

            self.target_label.setText(
                f"Texture en cours de modification :\n"
                f"{path}"
            )

        except Exception as error:

            QMessageBox.critical(
                self,
                "SWPaint",
                f"Impossible de charger la texture :\n{error}"
            )

    # --------------------------------------------------
    # APPLY TO ORIGINAL TEXTURE
    # --------------------------------------------------

    def apply_to_texture(self):

        if not self.target_path:
            QMessageBox.warning(
                self,
                "SWPaint",
                "Cette image ne vient pas d'une texture "
                "Geometry Dash ou Roblox.\n\n"
                "Utilise Exporter PNG pour l'enregistrer."
            )
            return

        confirm = QMessageBox.question(
            self,
            "Remplacer la texture",
            "Remplacer la texture originale par ton dessin ?\n\n"
            "Une sauvegarde sera créée automatiquement.",
            QMessageBox.StandardButton.Yes
            | QMessageBox.StandardButton.No
        )

        if confirm != QMessageBox.StandardButton.Yes:
            return

        try:
            backup_texture(
                self.target_path,
                self.target_root,
                self.target_game
            )

            image = qimage_to_pil(
                self.canvas.image
            )

            original_size = save_image_to_texture(
                image,
                self.target_path
            )

            QMessageBox.information(
                self,
                "SWPaint",
                "Texture enregistrée !\n\n"
                f"Dimensions conservées : "
                f"{original_size[0]} × {original_size[1]}"
            )

        except Exception as error:

            QMessageBox.critical(
                self,
                "Erreur d'enregistrement",
                f"Impossible d'enregistrer la texture :\n{error}"
            )


# --------------------------------------------------
# MAIN APPLICATION
# --------------------------------------------------

class SWLauncher(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            f"{APP_NAME} V{VERSION}"
        )

        self.resize(1250, 780)
        self.setMinimumSize(950, 620)

        BACKUP_FOLDER.mkdir(
            parents=True,
            exist_ok=True
        )

        self.setup_ui()
        self.setStyleSheet(BLUE_STYLE)

        self.load_default_folders()

    def setup_ui(self):

        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QHBoxLayout(central)

        main_layout.setContentsMargins(
            12, 12, 12, 12
        )

        main_layout.setSpacing(12)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(215)

        sidebar_layout = QVBoxLayout(sidebar)

        logo = QLabel("SWLAUNCHER")
        logo.setObjectName("Logo")

        version = QLabel(
            "BLUE EDITION  •  V1.1"
        )
        version.setObjectName("Version")

        sidebar_layout.addWidget(logo)
        sidebar_layout.addWidget(version)
        sidebar_layout.addSpacing(25)

        self.gd_button = QPushButton("Geometry Dash")
        self.roblox_button = QPushButton("Roblox")
        self.paint_button = QPushButton("SWPaint")

        self.gd_button.clicked.connect(
            lambda: self.switch_page(0)
        )

        self.roblox_button.clicked.connect(
            lambda: self.switch_page(1)
        )

        self.paint_button.clicked.connect(
            lambda: self.switch_page(2)
        )

        sidebar_layout.addWidget(self.gd_button)
        sidebar_layout.addWidget(self.roblox_button)
        sidebar_layout.addWidget(self.paint_button)

        sidebar_layout.addStretch()

        footer = QLabel("TEXTURE MANAGER")
        footer.setObjectName("Muted")

        sidebar_layout.addWidget(footer)

        self.pages = QStackedWidget()

        self.gd_page = TextureBrowser(
            "Geometry Dash",
            "Explore et modifie les textures de Geometry Dash.",
            default_folder=GD_DEFAULT,
            backup_name="GeometryDash",
            on_edit=self.open_in_paint
        )

        self.roblox_page = TextureBrowser(
            "Roblox",
            "Explore et modifie les textures du client Roblox.",
            backup_name="Roblox",
            on_edit=self.open_in_paint
        )

        self.paint_page = SWPaint(
            self.apply_paint_to_texture
        )

        self.pages.addWidget(self.gd_page)
        self.pages.addWidget(self.roblox_page)
        self.pages.addWidget(self.paint_page)

        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.pages, 1)

    # --------------------------------------------------
    # LOAD FOLDERS
    # --------------------------------------------------

    def load_default_folders(self):

        if GD_DEFAULT.exists():
            self.gd_page.load_root(GD_DEFAULT)

        roblox_folder = find_roblox_textures()

        if roblox_folder:
            self.roblox_page.load_root(
                roblox_folder
            )

        else:
            self.roblox_page.folder_label.setText(
                "Roblox introuvable. "
                "Vérifie que le client est installé."
            )

    # --------------------------------------------------
    # NAVIGATION
    # --------------------------------------------------

    def switch_page(self, index):
        self.pages.setCurrentIndex(index)

    # --------------------------------------------------
    # OPEN SWPAINT
    # --------------------------------------------------

    def open_in_paint(self, path, root, game_name):

        self.paint_page.load_texture(
            path,
            root,
            game_name
        )

        self.switch_page(2)

    def apply_paint_to_texture(self):
        self.paint_page.apply_to_texture()


# --------------------------------------------------
# START
# --------------------------------------------------

if __name__ == "__main__":

    app = QApplication(sys.argv)

    app.setApplicationName(APP_NAME)

    window = SWLauncher()
    window.show()

    sys.exit(app.exec())