@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconfirm --windowed --name SWLAUNCHER app.py
echo.
echo EXE cree dans le dossier dist.
pause
