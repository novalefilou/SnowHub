# SWLAUNCHER V0.3

## Nouveauté
- Le launcher détecte tous les fichiers `*.json` dans `%APPDATA%\\.minecraft\\assets\\indexes`.
- Chaque index apparaît dans une liste déroulante.
- `34.json` est volontairement exclu de la liste.
- Choisir un autre index recharge les textures correspondant à cette version.

## Lancer
1. Décompresser le ZIP.
2. Installer Python 3.10 ou plus récent.
3. Double-cliquer sur `run.bat`.

## Minecraft
Les images sont lues dans `assets/objects/<2 premiers caractères du hash>/<hash>`.
Importer un PNG crée un override dans `.minecraft/resourcepacks/SWLAUNCHER_Pack`.
Active ensuite le pack dans Options > Packs de ressources.

Les fichiers originaux ne sont pas modifiés.
Le `pack_format` est actuellement réglé sur 34 ; il pourra être adapté à la version Minecraft utilisée.
